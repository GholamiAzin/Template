export const updateReducer =(state, action)=>{
    switch (action.type) {

        case 'update':
            {
                const copyUpdateState = [...state]
                const stateIndex = state.findIndex((item)=>{return item.id === action.data.id})
                copyUpdateState.splice(stateIndex, 1, action.data)
                console.log('copyUpdateState',copyUpdateState);
                return copyUpdateState
            }
        default:
            return state;
    }
}

export const reducer = (state ,action)=>{
    switch (action.type) {
        case 'add':
            {
                const copyAddState = [...state]
                copyAddState.push(action.data)
                console.log('copyAddState',copyAddState);
                return copyAddState
            }
        case 'delete':
            {
                const deleteStateIndex = state.findIndex((item)=>{return item.id === action.data.id})
                const copyDeleteState = [...state]
                copyDeleteState.splice(deleteStateIndex , 1)
                return copyDeleteState
            }
        default:
            return state
    }
}



// const reducer =(state, action) =>{
//     switch (action.type) {
//       case 'add':
//         {
//           const copyAddState = [...state]
//           copyAddState.push(action.data )
//           return copyAddState
          
//         }
//       case 'edit':
//         {
//           const copyEditState = [...state]
//           const stateEditIndex = state.findIndex((item)=>{return item.id === action.data.id})
//           copyEditState.splice(stateEditIndex, 1, action.data)
//           console.log('copyEditState',copyEditState);
//           return copyEditState


//           // console.log("stateEditIndex",stateEditIndex);
//         }
//       case 'delete':
//         {
//           const stateDeleteIndex = state.findIndex((item)=>{return item.id === action.data.id})
//           const copyDeleteState = [...state]
//           copyDeleteState.splice(stateDeleteIndex, 1)
//           return copyDeleteState
//         }
//       }
//     }