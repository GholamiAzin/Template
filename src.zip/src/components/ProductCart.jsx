import ExplanationProduct from "./base/ExplanationProduct"
import PictureProduct from "./base/PictureProduct"

const ProductCart = ({children,src,cost,productName,material,productClass,productCartId,rate}) => {

  // console.log("rate",rate);

  return (
    <div className={`${productClass} rounded md:w-[45%] sm:w-full`}>
        <PictureProduct src={src} pictureProductId={productCartId}/>
        <ExplanationProduct expRate={rate} explanationProductId={productCartId} productMaterial={material} cost={cost} productName={productName}/>
        {children}
    </div>
  )
}

export default ProductCart