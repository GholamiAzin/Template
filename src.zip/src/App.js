// import './App.css';
import Home from './views/Home';

function App() {
  return (
    <>
      <Home/>
      {/* <img src={'./assets/Images/image-1.png'}/> */}
      {/* <img src={ require('./assets/Images/image-1.png') } /> */}
    </>
  );
}

export default App;
